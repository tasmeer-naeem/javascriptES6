const addbtn=document.getElementById("add")

const UpdataLSData=()=>{
    const textareadata=document.querySelectorAll("textarea")
    const notes=[]
    //console.log(textareadata)

    textareadata.forEach(note => {
        return notes.push(note.value)
    });
    //console.log(notes)
    localStorage.setItem("notes",JSON.stringify(notes))
}

const AddNewNote=(text = "")=>{

    const note=document.createElement("div")
    note.classList.add("note")
    const htmldata=` 
            <div class="operation">
                <button class="edit"><i class="far fa-edit"></i></button>
                <button class="delete"><i class="far fa-trash-alt"></i></button>
            </div>
            <div class="main ${text ? "" : "Hidden" } " ></div>
            <textarea class="  ${text ? "Hidden" : "" }" ></textarea> `
     note.insertAdjacentHTML("afterbegin",htmldata)
     //console.log(note)
     
     const editbtn=note.querySelector(".edit")
     const deletebtn=note.querySelector(".delete")
     const maindiv=note.querySelector(".main")
     const textarea=note.querySelector("textarea")

     deletebtn.addEventListener("click",()=>{
            note.remove()
            UpdataLSData()
     })

     textarea.value=text
     maindiv.innerHTML=text

     editbtn.addEventListener("click",()=>{
        maindiv.classList.toggle("Hidden")
        textarea.classList.toggle("Hidden")
    })

    textarea.addEventListener("change",(event)=>{
        const val=event.target.value
       // console.log(val)
       maindiv.innerHTML=val

       UpdataLSData()
    })
    document.body.appendChild(note)
}
const notes=JSON.parse(localStorage.getItem("notes"))
if(notes){
    notes.forEach((note)=>{
        AddNewNote(note)
    })
}

addbtn.addEventListener("click",()=>{ AddNewNote()})

