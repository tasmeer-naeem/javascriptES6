// var yearrr=2021;
// //debugger;
// if(yearrr % 4 == 0){
// if(yearrr % 100 == 0){
// if(yearrr % 400 == 0){
//     console.log(`the yearrr ${yearrr} is  a leap yearrr`)
// }
// else{
//     console.log(`the yearrr ${yearrr} is not a leap yearrr`)
// }   
// }
// else{
//     console.log(`the yearrr ${yearrr} is a leap yearrr`)
// }
// }
// else{
//     console.log(`the yearrr ${yearrr} is not a leap yearrr`)
// }
//OR
// var yearr = 2021;
//     if(yearr % 4 === 0 && yearr % 100 !== 0)
//     {
//         console.log("Leap year");
//     }
//     else
//     {
//         console.log("Not a leap year");
//     }

// var area='square'
// var pi=3.142 , l=2 , b=3 , h=4
// switch(area){
//     case "circle":
//         console.log(`circle ${l*b*h}`) 
//     break
//     case "tringle":
//         console.log(`triangle ${l*b*h}`)
//     break
//     default:
//         console.log("enter valid data")
//     break
// }

//  for (var num=1;num<=10;num++){
//     var table=7
//     console.log(`${table} * ${num} = ${table*num}`)
//  }

// function sum(a,b) {
//     var total=a+b
//     console.log(total)  
// }
// var funcExp=sum(7,8)
// funcExp;

// const sum=(a,b)=>{
//     return a+b
// }
// console.log(sum(6,7))

// let curdate=new Date()
// console.log(curdate.toString())
// console.log(curdate.toLocaleString())
// console.log(curdate.getDay())
// //console.log(curdate.setHours(5).toLocaleString())
// console.log(curdate.getHours())
// console.log(curdate.setMonth("November").toLocaleString())

